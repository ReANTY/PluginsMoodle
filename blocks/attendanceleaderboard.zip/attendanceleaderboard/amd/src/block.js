// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * AMD module for ACMLS block interactions.
 *
 * @module     block_attendanceleaderboard/block
 * @copyright  2024 ACMLS Project
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define(['jquery', 'core/ajax', 'core/notification'], function($, Ajax, Notification) {
    'use strict';

    var recordInteraction = function(userid, courseid, interactionType, data) {
        Ajax.call([{
            methodname: 'block_attendanceleaderboard_record_interaction',
            args: {
                userid: userid,
                courseid: courseid,
                interaction_type: interactionType,
                data: JSON.stringify(data || {})
            }
        }])[0].fail(function(err) {
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('ACMLS: failed to record interaction', err);
            }
        });
    };

    var submitMotivationFeedback = function(payload) {
        return Ajax.call([{
            methodname: 'block_attendanceleaderboard_submit_motivation_feedback',
            args: payload
        }])[0];
    };

    var showPopup = function($popup, userid, courseid) {
        if ($popup.data('initialised')) {
            return;
        }

        $popup.data('initialised', true);
        window.setTimeout(function() {
            $popup.addClass('is-visible');
        }, 80);

        recordInteraction(userid, courseid, 'encouragement_popup_shown', {
            sentenceid: Number($popup.data('sentenceid') || 0),
            category: $popup.data('category') || '',
            source: $popup.data('source') || ''
        });
    };

    var init = function(userid, courseid) {
        $(document).on('click', '.acmls-resource-link', function() {
            var $link = $(this);
            recordInteraction(userid, courseid, 'resource_accessed', {
                resourceid: $link.data('resourceid')
            });
        });

        $(document).on('submit', '.acmls-motivation-feedback-form', function(e) {
            e.preventDefault();

            var $form = $(this);
            var $popup = $form.closest('.acmls-motivation-popup');
            var sentenceId = Number($popup.data('sentenceid') || 0);
            
            var e1_name = 'acmls-e1-' + userid + '-' + sentenceId;
            var e2_name = 'acmls-e2-' + userid + '-' + sentenceId;
            var e3_name = 'acmls-e3-' + userid + '-' + sentenceId;

            var $e1_selected = $form.find('input[name="' + e1_name + '"]:checked');
            var $e2_selected = $form.find('input[name="' + e2_name + '"]:checked');
            var $e3_selected = $form.find('input[name="' + e3_name + '"]:checked');
            
            var $required = $form.find('.acmls-motivation-popup__required');
            var $submit = $form.find('.acmls-motivation-popup__submit');

            if (!$e1_selected.length || !$e2_selected.length || !$e3_selected.length) {
                $required.removeClass('d-none');
                return;
            }

            $required.addClass('d-none');
            $submit.prop('disabled', true);

            submitMotivationFeedback({
                userid: userid,
                courseid: courseid,
                sentenceid: sentenceId,
                category: $popup.data('category') || '',
                source: $popup.data('source') || '',
                message_content: $popup.data('content') || '',
                e1: Number($e1_selected.val() || 0),
                e2: Number($e2_selected.val() || 0),
                e3: Number($e3_selected.val() || 0),
                reflection_note: $form.find('textarea[name="reflection_note"]').val() || ''
            }).done(function() {
                $popup.removeClass('is-visible').addClass('is-submitted');
                window.setTimeout(function() {
                    $popup.remove();
                }, 250);
            }).fail(function(err) {
                $submit.prop('disabled', false);
                Notification.exception(err);
            });
        });

        $('.acmls-motivation-popup').each(function() {
            showPopup($(this), userid, courseid);
        });
    };

    return {
        init: init
    };
});
